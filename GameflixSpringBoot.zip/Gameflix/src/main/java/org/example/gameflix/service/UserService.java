package org.example.gameflix.service;

import org.example.gameflix.model.User;
import org.example.gameflix.model.UserDTO;
import org.example.gameflix.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Registers a new user
     * @param userDTO the user data from the request
     * @return Map containing success/error message
     */
    public Map<String, String> registerUser(UserDTO userDTO) {
        Map<String, String> response = new HashMap<>();

        // Validate input
        if (userDTO.getUsername() == null || userDTO.getUsername().trim().isEmpty()) {
            response.put("message", "Username cannot be empty");
            return response;
        }

        if (userDTO.getPassword() == null || userDTO.getPassword().length() < 6) {
            response.put("message", "Password must be at least 6 characters");
            return response;
        }

        // Check if username already exists
        if (userRepository.existsByUsername(userDTO.getUsername())) {
            response.put("message", "Username already exists");
            return response;
        }

        try {
            // Hash the password
            String hashedPassword = passwordEncoder.encode(userDTO.getPassword());

            // Create and save new user
            User newUser = new User(userDTO.getUsername(), hashedPassword);
            userRepository.save(newUser);

            response.put("message", "User registered successfully");
            return response;
        } catch (Exception e) {
            response.put("message", "Registration failed: " + e.getMessage());
            return response;
        }
    }

    /**
     * Authenticates a user
     * @param userDTO the login credentials
     * @return Map containing success/error message
     */
    public Map<String, String> authenticateUser(UserDTO userDTO) {
        Map<String, String> response = new HashMap<>();

        // Validate input
        if (userDTO.getUsername() == null || userDTO.getUsername().trim().isEmpty()) {
            response.put("message", "Username cannot be empty");
            return response;
        }

        if (userDTO.getPassword() == null || userDTO.getPassword().trim().isEmpty()) {
            response.put("message", "Password cannot be empty");
            return response;
        }

        try {
            // Find user by username
            User user = userRepository.findByUsername(userDTO.getUsername())
                    .orElse(null);

            // Check if user exists
            if (user == null) {
                response.put("message", "Invalid username or password");
                return response;
            }

            // Check if password matches
            boolean passwordMatches = passwordEncoder.matches(
                    userDTO.getPassword(),
                    user.getPasswordHash()
            );

            if (passwordMatches) {
                response.put("message", "Login successful");
                return response;
            } else {
                response.put("message", "Invalid username or password");
                return response;
            }
        } catch (Exception e) {
            response.put("message", "Login failed: " + e.getMessage());
            return response;
        }
    }

    /**
     * Checks if a user exists (helper method)
     * @param username the username to check
     * @return true if user exists
     */
    public boolean userExists(String username) {
        return userRepository.existsByUsername(username);
    }
}