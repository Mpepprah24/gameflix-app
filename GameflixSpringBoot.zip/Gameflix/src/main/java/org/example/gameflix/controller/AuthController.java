package org.example.gameflix.controller;

import org.example.gameflix.model.UserDTO;
import org.example.gameflix.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class AuthController {

    @Autowired
    private UserService userService;

    /**
     * Endpoint for user registration
     * POST /api/register
     */
    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> registerUser(@RequestBody UserDTO userDTO) {
        // Delegate to service
        Map<String, String> response = userService.registerUser(userDTO);

        // Check if registration was successful
        if (response.containsKey("message") && response.get("message").equals("User registered successfully")) {
            return ResponseEntity.ok(response);
        } else if (response.containsKey("message") && response.get("message").equals("Username already exists")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    /**
     * Endpoint for user login
     * POST /api/login
     */
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> loginUser(@RequestBody UserDTO userDTO) {
        // Delegate to service
        Map<String, String> response = userService.authenticateUser(userDTO);

        // Check if login was successful
        if (response.containsKey("message") && response.get("message").equals("Login successful")) {
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
    }

    /**
     * Health check endpoint (optional)
     * GET /api/health
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> healthCheck() {
        Map<String, String> response = Map.of("status", "OK", "message", "GameFlix API is running");
        return ResponseEntity.ok(response);
    }
}